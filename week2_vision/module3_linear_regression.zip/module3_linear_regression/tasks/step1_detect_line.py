"""
MIT BWSI Autonomous Drone Racing Course - UAV Neo
GNU General Public License v3.0

Week 2/3 Lab — Step 1: Detect the Line Pixels
Find the colored line pixels in the downward camera.
"""

import drone_core
import drone_utils as uav_utils
import cv2
import numpy as np

# -- Course setup: makes the shared `neo_lab` helper importable.
#    You don't need to read or change this block. --
import os as _os, sys as _sys
_d = _os.path.dirname(_os.path.realpath(__file__))
while _os.path.basename(_d) != "labs" and _os.path.dirname(_d) != _d:
    _d = _os.path.dirname(_d)
if _d not in _sys.path:
    _sys.path.insert(0, _d)
import neo_lab

# -- Constants --------------------------------------------------------------
S_MIN         = 100
ADVANCE_PITCH = 1      # fly forward off the spawn pad to reach the line
ADVANCE_TIME  = 3       # seconds of forward flight before reporting

# -- Module-level state -----------------------------------------------------
_timer = 0.0
_done  = False

def reset():
    global _timer, _done
    _timer = 0.0
    _done  = False


def update(drone):
    global _timer, _done
    if _done:
        return True
    drone.flight.stop()   # hover in place
    ##################################
    #### START PUT CODE HERE #########

    # The drone spawns on a colored landing pad, so first fly forward (ADVANCE_PITCH) for
    # ADVANCE_TIME to reach the line, then hover. The line is vivid against a grey floor, so
    # threshold by saturation: neo_lab.saturated_mask(image, S_MIN) gives a mask of the line
    # pixels. Count them, print the count, and set _done. See the README (Key terms).

    drone.flight.send_pcmd(1, 0, 0, 0)

    _timer += drone.get_delta_time()

    if _timer > ADVANCE_TIME:
        _done = True
        drone.flight.stop()

    ###### END PUT CODE HERE #########
    ##################################
    return _done


if __name__ == "__main__":
    _drone = drone_core.create_drone()

    def start():
        reset()
        print("Step 1: Detect the Line Pixels")

    def _update():
        if update(_drone):
            _drone.flight.land()

    _drone.set_start_update(start, _update)
    _drone.go()
