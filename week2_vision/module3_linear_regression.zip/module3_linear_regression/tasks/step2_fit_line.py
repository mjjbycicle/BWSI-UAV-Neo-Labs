"""
MIT BWSI Autonomous Drone Racing Course - UAV Neo
GNU General Public License v3.0

Week 2/3 Lab — Step 2: Fit a Line (Least Squares)
Fit y = m*x + b to the colored line pixels with linear regression.
"""

import bisect
# -- Course setup: makes the shared `neo_lab` helper importable.
#    You don't need to read or change this block. --
import os as _os
import sys as _sys

import numpy as np

import drone_core
import drone_utils

_d = _os.path.dirname(_os.path.realpath(__file__))
while _os.path.basename(_d) != "labs" and _os.path.dirname(_d) != _d:
    _d = _os.path.dirname(_d)
if _d not in _sys.path:
    _sys.path.insert(0, _d)
import neo_lab
from . import PDControl
from . import line_util as lu
from . import cam_util as cu

# -- Constants --------------------------------------------------------------
S_MIN = 100
MIN_PIXELS = 200
ADVANCE_PITCH = 0.15  # fly forward off the spawn pad to reach the line
ADVANCE_TIME = 8.0  # seconds of forward flight before fitting
K_CURVE = 0.1
COL_CENTER = 320

# -- Module-level state -----------------------------------------------------
_timer = 0.0
_done = False
_was_green = False
_lap = 0
_return_timer = 0.0
_prev_roll_err = 0.0

full_controller = PDControl.FullController()
roll_controller = PDControl.PDController(0.008, 0.06, 0.2)


def reset():
    global _timer, _done
    _timer = 0.0
    _done = False


def update(drone):
    global _timer, _done, _was_green, _lap, ADVANCE_PITCH, _prev_roll_err, _return_timer
    if _done:
        return True
    drone.flight.stop()  # hover in place
    ##################################
    #### START PUT CODE HERE #########

    # First fly forward (ADVANCE_PITCH) for ADVANCE_TIME to leave the spawn pad, then hover.
    # Build the colored-line mask like Step 1 and collect the (row, col) of every line pixel.
    # If there are fewer than MIN_PIXELS, there is not enough line to fit -> return False.
    # Otherwise call fit_line() and print m, b, then set _done.

    dt = drone.get_delta_time()
    image = drone.camera.get_downward_image()
    _timer += dt

    green_fraction = lu.get_green_fraction(image)
    if green_fraction > 0.005:
        if not _was_green:
            _was_green = True
            _lap += 1
            print(f"lap {_lap}, time = {_timer}")
            _timer = 0.0
    else:
        _was_green = False

    _mask = neo_lab.saturated_mask(image, S_MIN)
    mask = lu.get_largest_component_optimized(_mask)
    points = np.argwhere(mask == 255)
    if len(points) < MIN_PIXELS or _return_timer != 0:
        _return_timer += dt
        if _return_timer > 3 and abs(_prev_roll_err) < 160:
            _return_timer = 0.0
            return False
        else:
            if len(points) > MIN_PIXELS and _return_timer > 2:
                directions, means = lu.fit_lines(points)
                roll_err = means[0][0] - COL_CENTER
                _prev_roll_err = roll_err
            else:
                roll_err = _prev_roll_err
            roll = roll_controller.calculate_position(roll_err, dt)
            drone.flight.send_pcmd(0, roll, 0, 0)
            return False
    directions, means = lu.fit_lines(points)
    angles = np.arctan(directions[:, 0] / directions[:, 1])
    angles = np.degrees(angles)
    curvature = angles[0] - angles[3]
    roll_err = means[0][0] - COL_CENTER
    target_angle = angles[0]
    target_angle -= roll_err / 30
    if abs(curvature) < 10 and abs(roll_err) < 160:
        curvature = 0
        ADVANCE_PITCH = 0.7
        roll_controller.kp = 0.008
        roll_controller.max_output = 0.2
    else:
        ADVANCE_PITCH = 0.6
        roll_controller.kp = 0.008
        if abs(roll_err) > 160:
            ADVANCE_PITCH = 0.6
            curvature = 0.0
            roll_controller.kp = 0.01
        roll_controller.max_output = 0.6
    if abs(angles[0] - angles[1]) < 2:
        curvature = -curvature
    curvature_ff = -curvature * 0.009
    full_controller.set_setpoint(_alt=8)
    roll = -roll_controller.calculate_position(roll_err, dt) + curvature_ff
    roll = drone_utils.clamp(roll, -1, 1)
    output = full_controller.calculate(_alt=drone.physics.get_altitude(),
                                       _alt_vel=drone.physics.get_linear_velocity()[1], _yaw=target_angle, dt=dt)
    drone.flight.send_pcmd(ADVANCE_PITCH, roll, output[2], output[3])
    _prev_roll_err = roll_err
    ###### END PUT CODE HERE #########
    ##################################
    return _done


if __name__ == "__main__":
    _drone = drone_core.create_drone()
    _launcher = neo_lab.Launcher(3.0)


    def start():
        _launcher.reset()
        reset()
        print("Step 2: Fit a Line (Least Squares)")


    def _update():
        if not _launcher.done:  # arm + climb to a safe height first
            _launcher.update(_drone)
            return
        if update(_drone):
            _drone.flight.land()


    _drone.set_start_update(start, _update)
    _drone.go()
